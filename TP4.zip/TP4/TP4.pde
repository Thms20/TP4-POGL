PShader monProgrammeShader; //1//
PShader monProgrammeShader2;

// Fait par Thomas Combeau  G2. Mettre en pleine écran pour avoir un résultat qui marche sinon tout est décalé.
void setup(){
  monProgrammeShader = 
    loadShader("myFragmentShader.glsl", 
               "myVertexShader.glsl"); //2//
  monProgrammeShader2 =   loadShader("myFragmentShader2.glsl", 
                                     "myVertexShader2.glsl");
  size(800, 700, P3D);
}

void petiteSphere() {
    rotateX(PI/3);
  
      for (int i=-200; i<=200; i++){
        float a = i/75.0*2*PI;
        translate(22*cos(a), 22*sin(a),-0.7);
        pushMatrix();
        noStroke();
        fill(192, 128, 64);
        sphere(7);
        popMatrix();
      }
}

void sphereCollante() {
  //  rotateX(PI/3);
  
      for (int i=-200; i<=200; i++){
        float a = i/50.0*2*PI;
        translate((12*cos(i*PI/400) +16.5)*cos(a), (12*cos(i*PI/400) + 16.5)*sin(a),-1.005);
        pushMatrix();
        noStroke();
        fill(192, 128, 64);
        sphere(8);
        popMatrix();
      }
}

void draw(){
//  rotateY(PI/2); // <-- vu pour voir le bas
  noStroke();
  fill(192, 128, 64);
  pointLight(255, 255, 255, mouseX, mouseY, 400);
  
  pushMatrix();
  shader(monProgrammeShader); //3//
  translate(width/4 + 10, height/2);
  sphereDetail(20);
  sphere(230);
  popMatrix(); 
  
  pushMatrix();  
  shader(monProgrammeShader2);
  translate(width/2 + 200,height/2);
  sphereDetail(20);
  sphere(230);
  popMatrix(); 
  
  translate(width/4 + 230, height/2 -80, 200);
  petiteSphere();

//  translate(width/2 + 195, height/2 - 240, -10); 
  translate(772, height/2 -615, 315);
  sphereCollante();  
}